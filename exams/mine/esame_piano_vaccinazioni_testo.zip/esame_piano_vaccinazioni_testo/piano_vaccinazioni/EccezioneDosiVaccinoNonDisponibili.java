package piano_vaccinazioni;

@SuppressWarnings("serial")
public class EccezioneDosiVaccinoNonDisponibili extends Exception{

}
