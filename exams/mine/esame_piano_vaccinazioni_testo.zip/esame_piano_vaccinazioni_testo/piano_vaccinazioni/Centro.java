package piano_vaccinazioni;

public class Centro {

	public String getCodice() {
		return null;
	}

	public String getRegione() {
		return null;
	}

	public int getNumeroMassimoDosi() {
		return -1;
	}


}
