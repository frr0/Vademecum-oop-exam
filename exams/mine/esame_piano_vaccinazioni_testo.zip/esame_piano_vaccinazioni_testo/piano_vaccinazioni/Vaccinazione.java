package piano_vaccinazioni;

public class Vaccinazione {
	
}
