package piano_vaccinazioni;

public class Cittadino {

	public String getCodiceTesseraSanitaria() {
		return null;
	}

	public String getNome() {
		return null;
	}

	public String getCognome() {
		return null;
	}

	public String getDataDiNascita() {
		return null;
	}

	public String getRegione() {
		return null;
	}
	
}
