package piano_vaccinazioni;

public class Richiamo extends Vaccinazione{

}
