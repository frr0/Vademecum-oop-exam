package network_professionisti;

public class CentroDiFormazione extends Entita{

}
