package network_professionisti;

public class Azienda extends Entita {

	public String getSettore() {
		return null;
	}

	public int getNumeroDipendenti() {
		return -1;
	}
	
}
