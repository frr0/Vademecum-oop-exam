package network_professionisti;

public class Entita {

	public String getNome() {
		return null;
	}

	public String getNazione() {
		return null;
	}

	public String getIndirizzo() {
		return null;
	}
}
