package network_professionisti;

public class Iscritto {

	public String getId() {
		return null;
	}

	public String getNome() {
		return null;
	}

	public String getCognome() {
		return null;
	}

	public String getWeb() {
		return null;
	}

	public String getEmail() {
		return null;
	}

	public String getDescrizione() {
		return null;
	}
	
}
