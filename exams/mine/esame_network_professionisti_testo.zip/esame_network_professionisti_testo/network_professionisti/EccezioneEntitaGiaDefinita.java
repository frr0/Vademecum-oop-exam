package network_professionisti;

@SuppressWarnings("serial")
public class EccezioneEntitaGiaDefinita extends Exception {

}
